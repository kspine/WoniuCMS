-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : woniucms
-- 
-- Part : #1
-- Date : 2015-01-07 23:36:53
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `woniu_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_auth_extend`;
CREATE TABLE `woniu_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';


-- -----------------------------
-- Table structure for `woniu_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_auth_group`;
CREATE TABLE `woniu_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `woniu_auth_group`
-- -----------------------------
INSERT INTO `woniu_auth_group` VALUES ('', '', '', '', '', '', '');
INSERT INTO `woniu_auth_group` VALUES ('', '', '', '', '', '', '');
INSERT INTO `woniu_auth_group` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `woniu_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_auth_group_access`;
CREATE TABLE `woniu_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `woniu_auth_group_access`
-- -----------------------------
INSERT INTO `woniu_auth_group_access` VALUES ('', '');
INSERT INTO `woniu_auth_group_access` VALUES ('', '');

-- -----------------------------
-- Table structure for `woniu_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_auth_rule`;
CREATE TABLE `woniu_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `pid` int(11) DEFAULT NULL,
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `url` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `is_menu` tinyint(1) unsigned zerofill NOT NULL DEFAULT '0',
  `tip` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `condition1` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`module`,`name`,`type`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=706 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `woniu_auth_rule`
-- -----------------------------
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_auth_rule` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `woniu_channel`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_channel`;
CREATE TABLE `woniu_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(50) NOT NULL COMMENT '标题',
  `router` varchar(30) NOT NULL COMMENT '标志',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `status` varchar(4) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `is_nav` varchar(255) DEFAULT NULL,
  `is_menu` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10003 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `woniu_channel`
-- -----------------------------
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_channel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `woniu_content`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_content`;
CREATE TABLE `woniu_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` varchar(10000) NOT NULL,
  `click` int(10) unsigned DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) DEFAULT NULL,
  `category_id` int(10) unsigned NOT NULL DEFAULT '0',
  `router` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `pic1` varchar(255) DEFAULT NULL,
  `pictures` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `woniu_content`
-- -----------------------------
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_content` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `woniu_member`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_member`;
CREATE TABLE `woniu_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `pwd` char(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `reg_ip` varchar(20) DEFAULT NULL,
  `reg_time` int(11) DEFAULT NULL,
  `last_login_ip` varchar(20) DEFAULT NULL,
  `last_login_time` int(11) DEFAULT NULL,
  `login_count` int(255) DEFAULT '0',
  `status` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='后台用户表';

-- -----------------------------
-- Records of `woniu_member`
-- -----------------------------
INSERT INTO `woniu_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `woniu_msg`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_msg`;
CREATE TABLE `woniu_msg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(32) DEFAULT NULL,
  `content` varchar(300) DEFAULT NULL,
  `sendTime` int(11) DEFAULT NULL,
  `sender` varchar(32) DEFAULT NULL,
  `senderID` int(5) DEFAULT NULL,
  `receiver` varchar(32) DEFAULT NULL,
  `receiverID` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `woniu_site_config`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_site_config`;
CREATE TABLE `woniu_site_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `woniu_site_config`
-- -----------------------------
INSERT INTO `woniu_site_config` VALUES ('', '', '');
INSERT INTO `woniu_site_config` VALUES ('', '', '');
INSERT INTO `woniu_site_config` VALUES ('', '', '');
INSERT INTO `woniu_site_config` VALUES ('', '', '');
INSERT INTO `woniu_site_config` VALUES ('', '', '');
INSERT INTO `woniu_site_config` VALUES ('', '', '');
INSERT INTO `woniu_site_config` VALUES ('', '', '');

-- -----------------------------
-- Table structure for `woniu_user`
-- -----------------------------
DROP TABLE IF EXISTS `woniu_user`;
CREATE TABLE `woniu_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `pwd` char(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `reg_ip` varchar(20) DEFAULT NULL,
  `reg_time` int(11) DEFAULT NULL,
  `last_login_ip` varchar(20) DEFAULT NULL,
  `last_login_time` int(11) DEFAULT NULL,
  `login_count` int(255) DEFAULT '0',
  `status` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='后台用户表';

-- -----------------------------
-- Records of `woniu_user`
-- -----------------------------
INSERT INTO `woniu_user` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `woniu_user` VALUES ('', '', '', '', '', '', '', '', '', '', '');
